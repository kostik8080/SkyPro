import random

# Чтение слов из файла
def read_words():
    with open("words.txt", "r") as f:
        words = f.readlines()
    return [w.strip() for w in words]

# Чтение топа игроков
def read_top():

    with open("history.txt", "r") as f:
        top = f.readlines()
    return [t.strip().split() for t in top]


#Запись результата в топ
def write_top(name, score):
    top = read_top()
    top.append([name, str(score)])
    top.sort(key=lambda x: int(x[1]), reverse=True)
    with open("history.txt", "w") as f:
        for t in top:
            f.write(t[0] + " " + t[1] + "\n")





# Основная программа
name = input("Введите ваше имя: ")

words = read_words()
random.shuffle(words)

score = 0
for word in words:
    jumble_word = ''.join(random.sample(word, len(word)))
    guess = input("Угадайте слово: " + jumble_word + "\n")
    if guess.lower() == word.lower():
        print("Верно!")
        score += 10
    else:
        print("Неверно! Верный ответ –", word)

write_top(name, score)

top = read_top()
num_games = len(top)
max_score = top[0][1]

print("Всего игр сыграно:", num_games)
print("Максимальный рекорд:", max_score)