import random

def load_words(filename):
    """
    Функция которая берет слова из файла и перебирает добавляя в новый список
    """
    new_lines = []

    with open(filename, "r", encoding="utf-8") as f:
        for line in f.readlines():
            new_lines.append(line.strip("\n"))
    return new_lines


def change_word(word):
    """
    Функция которая перемешивает слово из списка и возвращяет в виде слова
    """
    word = list(word)
    random.shuffle(word)
    return ''.join(word)

def write_history(filename, user_name, score):
    """
    Функция котарая добавляет результат Имени пользователя и балов
    """
    with open(filename, "a", encoding="utf8") as f:
        f.write(f"{user_name} {score} \n")


def read_history(filename):
    """
    Функция считовает файл с именем и балами и
    считает сколко раз сыграно и моксимальны счет балов
    """
    max = 0
    count = 0

    with open(filename, "r", encoding="utf-8") as f:
        for line in f.readlines():
            count += 1
            score = int(line.split(" ")[1])
            if score > max:
                max = score
    return f"Всего игр сыграно {count} \n"\
            f"Моксимальный рекорд {max}"