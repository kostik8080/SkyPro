# Импортируем из файла наши функции
from util import load_words, change_word, write_history, read_history

#Основная логика программы
if __name__ == "__main__":
    word_txt = "words.txt"
    history_txt = "history.txt"

# Ввод пользователя
    print("Введите ваше имя")
    user_name = input()
    words = load_words(word_txt)

# Счетчик балов
    score = 0

# Цикл который выдает смешанное слово и проверяет правильно или нет
    for word in words:
        print(change_word(word))
        user_answer = input()
        if user_answer.lower().strip(" ") == word:
            print("Верно вы получаете 10 очков")
            score += 10
        else:
            print(f"Не верно! Верный ответ {word} ")

# После как на все ответили выдает сколько раз сыграли и максимальный рекорд балов
    write_history(history_txt, user_name, score)

    print(read_history(history_txt))
